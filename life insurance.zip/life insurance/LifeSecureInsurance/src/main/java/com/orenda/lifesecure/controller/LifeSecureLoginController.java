package com.orenda.lifesecure.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.orenda.lifesecure.model.UserDetails;
import com.orenda.lifesecure.service.LifeSecureLoginService;

@Controller

public class LifeSecureLoginController {

	@Autowired
	LifeSecureLoginService loginService;

	@GetMapping("/")
	public String loginPage() {
		System.out.println("inside login");
		return "login";
	}

	@GetMapping("/verifyUser")
	public String verifyUser(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		System.out.println("login method called::: username::" + username + "  password:: " + password);
		System.out.println("login sucess");

		String status = loginService.verifyUserCredentilas(username, password);

		if (status.equalsIgnoreCase("admin")) {
			System.out.println(" admin login sucess");

			return "admin";
		} else if (status.equalsIgnoreCase("customer")) {
			System.out.println("customer login success");
			return "customer";

		} else if (status.equalsIgnoreCase("agent")) {
			System.out.println("agent login success");
			return "agent";

		}

		else {
			System.out.println("your password or username is incorrect");
		}

		return "login";

	}

}
