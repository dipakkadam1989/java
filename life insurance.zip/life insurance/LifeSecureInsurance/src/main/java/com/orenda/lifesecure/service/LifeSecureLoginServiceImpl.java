package com.orenda.lifesecure.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;
import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Service

public class LifeSecureLoginServiceImpl implements LifeSecureLoginService {

	@Autowired
	LifeSecureLoginDao logindao;

	public String verifyUserCredentilas(String username, String password) {
		
		System.out.println("service");
		User user = logindao.getUserDetailsByEmailId(username);

		if (user != null && user.getPassword().equals(password)) {
			UserDetails userdetails = logindao.getUserType(username);

			if (userdetails.getUsertype().equalsIgnoreCase("admin")) {
				// System.out.println("user is admin");
				return "admin";
			} else if (userdetails.getUsertype().equalsIgnoreCase("customer")) {
				return "customer";
			}

			else if (userdetails.getUsertype().equalsIgnoreCase("agent")) {
				return "agent";
			}

		}
		return null;
		
		

	}

}
