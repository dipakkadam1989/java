package com.orenda.lifesecure.service;

import java.util.List;

import com.orenda.lifesecure.model.UserDetails;

public interface LifeSecureLoginService {

	 String verifyUserCredentilas(String username, String password);
	


}
