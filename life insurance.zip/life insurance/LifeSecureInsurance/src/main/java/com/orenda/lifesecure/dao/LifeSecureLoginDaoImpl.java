package com.orenda.lifesecure.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.validator.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Repository

public class LifeSecureLoginDaoImpl implements LifeSecureLoginDao {

	@Autowired

	SessionFactory sessionFactory;

	public User getUserDetailsByEmailId(String username) {

		Session session = sessionFactory.openSession();
		// Query query = session.createQuery("from User where userEmail=?");
		// User user = (User) query.setParameter(0, username).getSingleResult();

		Query query = session.createQuery("from User where useremail=?");
		User user = (User) query.setParameter(0, username).getSingleResult();

		System.out.println(user.toString());
//		
		return user;
	}

	@Override
	public UserDetails getUserType(String username) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from UserDetails where userEmail=?");
		UserDetails userdetails = (UserDetails) query.setParameter(0, username).getSingleResult();
		System.out.println(userdetails);
		return userdetails;
	}

	public List<UserDetails> getData() {
		Session session = sessionFactory.openSession();
		@SuppressWarnings("rawtypes")
		List userList = session.createCriteria(UserDetails.class).list();
		
		return userList;

	}
}
