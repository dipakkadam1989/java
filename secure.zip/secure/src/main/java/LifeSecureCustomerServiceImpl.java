

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.lifesecure.dao.LifeSecureCustomerDao;
import com.orenda.lifesecure.model.PolicyDetails;
import com.orenda.lifesecure.model.TransactionHistory;
import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Service
public class LifeSecureCustomerServiceImpl implements LifeSecureCustomerService {
    
	@Autowired
	LifeSecureCustomerDao loginCustomerDao;
	
	
	@Override
	public UserDetails getCustomer() {
		// TODO Auto-generated method stub
		return loginCustomerDao.getCustomer();
	}
	@Override
	public PolicyDetails getCustomer1() {
		// TODO Auto-generated method stub
		return loginCustomerDao.getCustomer1();
	}


	@Override
	public List<TransactionHistory> getAllTransactionList() {
	
		return loginCustomerDao.getAllTransactionList();
	}
	
	
	@Override
	public UserDetails editUserDetailsById(int userId) {
		// TODO Auto-generated method stub
		return loginCustomerDao.editUserRecord(userId);
	}

	


	
}
