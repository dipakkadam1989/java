package com.orenda.lifesecure.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.orenda.lifesecure.model.UserDetails;
import com.orenda.lifesecure.service.LifeSecureLoginService;

@Controller

public class LifeSecureLoginController {

	@Autowired
	LifeSecureLoginService loginService;

	@GetMapping("/")
	public String loginPage() {
		System.out.println("inside login");
		return "login";
	}

	@GetMapping("/verifyUser")
	public ModelAndView verifyUser(@RequestParam("username") String username, @RequestParam("password") String password,
			 HttpSession session) {
		System.out.println("login method called::: username::" + username + "  password:: " + password);
		System.out.println("login sucess");

		 UserDetails userdetails = loginService.verifyUserCredentilas(username, password);
		 
		 ModelAndView model=null;
		 if(userdetails==null) {
			 model=new ModelAndView("login", "msg","Please Enter Correct username or password Please Try Again To Login ");
			 return model;
		 }

		if (userdetails.getUsertype().equalsIgnoreCase("admin")) {
			System.out.println(" admin login sucess");
			model=new ModelAndView("admin");
			return model;
		} else if (userdetails.getUsertype().equalsIgnoreCase("customer")) {
			System.out.println("customer login success");
			model=new ModelAndView("customer");
			return model;

		} else if (userdetails.getUsertype().equalsIgnoreCase("agent")) {
			System.out.println("agent login success");
			model=new ModelAndView("agent");
			return model;

		}

		else {
			System.out.println("your password or username is incorrect");
		}

		return model;

	}

}
