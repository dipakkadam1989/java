package com.orenda.lifesecure.dao;

import java.util.List;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

public interface LifeSecureLoginDao {

	User getUserDetailsByEmailId(String username);

	UserDetails getUserType(String username);
	List<UserDetails> getData();

}
