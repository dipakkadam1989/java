package com.orenda.lifesecure.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.validator.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Repository

public class LifeSecureLoginDaoImpl implements LifeSecureLoginDao {

	@Autowired

	SessionFactory sessionFactory;

	public User getUserDetailsByEmailId(String username) {

		Session session = sessionFactory.openSession();
		// Query query = session.createQuery("from User where userEmail=?");
		// User user = (User) query.setParameter(0, username).getSingleResult();
		User user=null;
		try {

		Query query = session.createQuery("from User where useremail=?");
		 user = (User) query.setParameter(0, username).getSingleResult();

		System.out.println(user.toString());
		}catch(Exception e) {
			
		}
//		
		return user;
	}

	@Override
	public UserDetails getUserType(String username) {
		Session session = sessionFactory.openSession();
		UserDetails userdetails=null;
		try {
		Query query = session.createQuery("from UserDetails where userEmail=?");
		userdetails = (UserDetails) query.setParameter(0, username).getSingleResult();
		System.out.println(userdetails);
		}catch(Exception e) {
			
		}
		return userdetails;
	}

	public List<UserDetails> getData() {
		Session session = sessionFactory.openSession();
		List <UserDetails>userList=null;
		try {
		
		  userList = session.createCriteria(UserDetails.class).list();
		}catch(Exception e) {
			
		}
		return userList;

	}
}
