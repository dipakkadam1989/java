package com.orenda.lifesecure.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;
import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Service

public class LifeSecureLoginServiceImpl implements LifeSecureLoginService {

	@Autowired
	LifeSecureLoginDao logindao;

	public UserDetails verifyUserCredentilas(String username, String password) {
		
		System.out.println("service");
		User user = logindao.getUserDetailsByEmailId(username);
		UserDetails userdetails=null;

		if (username != null && user != null && user.getPassword() != null && user.getPassword().equals(password)) {
			try {
			 userdetails = logindao.getUserType(username);
			}catch(Exception e) {
				e.printStackTrace();
			}

		}
		return userdetails;
		
		
		

	}

}
